var water,frog,coin,climber;
var waterImg,frogImg,coinImg,climberImg;
var score = 0;
var coinG,climberG;


//Game States
var gameState=0;

//to load the images
function preload(){
  waterImg = loadImage("water.jpg");
  //to load the animation
  frogImg = loadImage("frog.png");
  coinImg = loadImage("coin.png");
  climberImg = loadImage("seaweed.png");
  endImg =loadImage("gameOver.png");
}

function setup(){
  
  createCanvas(500,500);
  //create moving water
  water=createSprite(200,200);
  water.addImage(waterImg);
  water.velocityY = 2;
  createEdgeSprites();


  //creating frog running
  frog = createSprite(150,420,100,100);
  frog.addImage(frogImg);
  frog.scale = 0.2;
  //frog.debug = true
  frog.setCollider("rectangle", 0, 10,220,300)
    
  // creating groups 
  coinG=new Group();
  climberG=new Group();
  
}

function draw() {
drawSprites();

  //When gamestate is play
  if(gameState == 0){
   fill("blue");
  textSize(18);
  text("Press spacebar to start the game", 100, 40);
   if(keyDown('space')){
   text("welcome", 120, 120);
   gameState = 1;
    }
  }
   
  if(gameState == 1){
    //background(0);
    textSize(22);
    fill("red");
    text("Score: "+ score,150,30);
    //moving the frog according to mouse; it can also be written as (frog.x = mouseX)
    
    
    
    //code to reset the background and give the effect of infinite background
    if(water.y > 300 ){
      water.y = 200;
    }
    createcoin();
    //createclimber();

    if (climberG.isTouching(frog)) {
      frog.velocityY = 0;
      //frog.x = 30;
    }
    if (coinG.isTouching(frog)) {
      //the coin group is getting destroyed when the frog is touching it
      coinG.destroyEach();
      //the score is increasing
      score=score+1;
    }
    if(keyDown("left")){
    frog.x = frog.x - 4;
  }

  if(keyDown("right")){
    frog.x = frog.x + 4;
  }
  if(keyDown("down")){
    frog.y = frog.y + 4;
  }
  if(frog.position.y >  490)
  {
    gameState = 2;
    frog.velocityX = -4;
  }
  if(keyDown('space'))
  {
    frog.velocityY = -4;
  }
   else{frog.velocityY = 3;}


  }


  if(gameState == 2){
    frog.addImage(endImg);
    frog.x=250;
    frog.y=250;
    frog.scale=.6;
    water.velocityY = 0;
    //all groups are getting destroyed
    coinG.destroyEach();
    climberG.destroyEach();
   
}

}


function createcoin() {
  if (frameCount % 100 == 0) {
  var coin = createSprite(Math.round(random(50, 350)),40, 10, 10);
  coin.addImage(coinImg);
  coin.scale=0.12;
  //coin.debug = true
  coin.velocityY = 3;
  coin.lifetime = 300;
  coinG.add(coin);
 
  //coinpos = coin.position.x;
var climber = createSprite(coin.x, 110, 10, 10);
//climber.debug = true;
//climber.setCollider("rectangle",0,0,400,100);
climber.addImage(climberImg);
climber.scale= .4;
// climber.debug = true
climber.velocityY = 3;
climber.lifetime = 300;
climberG.add(climber);
}
}